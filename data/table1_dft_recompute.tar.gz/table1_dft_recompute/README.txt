Table 1 DFT comparators: property-matched-basis recompute
==========================================================

Data behind the BP86 / B3LYP / DSD-PBEP86 columns of Table 1 of
"Coupled-cluster molecular properties across the main group that extrapolate
beyond training size" (arXiv:2608.18346). Reproduce the table with
scripts/table1.py in https://github.com/He-Wenhao/HARP (see its README,
"Reproduce Table 1").

Each functional is evaluated at the basis of the property's coupled-cluster
reference (ORCA 6.1.1; inputs in HARP orca_templates/table1_*):

  obs_pvtz/<method>/<idx>.json   cc-pVTZ single points -> energy (E_total, Ha),
                                 dipole (a.u.), quadrupole (a.u.; order XX YY ZZ
                                 XY XZ YZ), Mulliken atomic_charge, Mayer
                                 bond_order [[i, j, value], ...].
                                 DSD-PBEP86 uses the MP2-relaxed density
                                 (%mp2 Density relaxed).
  obs_pvdz/<method>/<idx>.json   cc-pVDZ single points with Polar -> alpha (3x3,
                                 a.u.; for DSD-PBEP86 the MP2 relaxed-density
                                 polarizability) and HOMO-LUMO gap Ee (eV).
  single_atom_ccpvtz.json        cc-pVTZ single-atom energies (Ha) of each
                                 functional, for comparing energies as
                                 atomization energies:
                                 E_aligned = E_total + sum_atoms (E_CCSDt[el] - E_func[el]),
                                 with E_CCSDt from HARP src/data/E_single.json.

<method> is BP86, B3LYP or DSD_PBEP86; <idx> is the dataset index.

Molecule set
------------
962 molecules: the 959-molecule held-out test set (labels in
main-group-cc_test-set-full-inputs.tar.gz, obs/) plus 3 molecules of the same
index range (325, 772, 889) that the model-in-the-loop outlier screen removed
from the test set (HARP dataset_filter/outliers_summary.txt). Their
coupled-cluster labels and geometries are in outliers/obs/ and
outliers/structures/.

The DFT columns printed in Table 1 were aggregated over all 962 molecules; the
HARP column is over the 959-molecule test set. Restricted to the 959 test
molecules, the DFT values change only in the third significant figure
(scripts/table1.py --set test prints them).
